const https = require('https');

// 1. TEMPEL KUNCI API GEMINI ANDA DI SINI
const GEMINI_API_KEY = [
    "AQ.Ab8RN6KL0qcvnsEy5iJFxVi9eiWBrUSwKCmYL654qj9mBrTAHw",
    "AQ.Ab8RN6IzE-I25e59HsTWOsQJoNy5TtAzS7bGR-z7L596DwSbxA",
    "AQ.Ab8RN6Jvy369xY55gyoW17mUWK0u4it6qaTgo9pbhup6qsjP6g",
    "AQ.Ab8RN6KsBiTrnJhu8wQqVZfj4hybtCJzirfaHrWA1VGiww7-NQ",
    "AQ.Ab8RN6IQF4rVGYLtCYmm54crjMW0EpANAihDePhYs6jhMWDA-g",
    "AQ.Ab8RN6KrVd1Q6_yIdfVLCPt62CQdmm1v5b6IlUvxcGyWUyYaRQ",
    "AQ.Ab8RN6IGiyW2d5zPAK7YohkDnk28SAQ9f93lU3sDG30lsPbhiA",
    "AQ.Ab8RN6JPwcKfLa5Moj3luaHoEd0es2K7aEoFuJy2pCIDv7HmMg",
    "AQ.Ab8RN6Ipp7jMHvaTCv_zPPfjSUJM_4JAMYdbOZFAArWN5p2vTw",
   ]

async function tanyaAI(pesanTeks) {
    return new Promise((resolve) => {
        // Menggunakan endpoint resmi Gemini 1.5 Flash tanpa library tambahan
        const randomKey = GEMINI_API_KEY[Math.floor(Math.random() * GEMINI_API_KEY.length)];
        const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${randomKey}`;
        
        
        const data = JSON.stringify({
            contents: [{ parts: [{ text: pesanTeks }] }],
          systemInstruction: {
            parts: [{
              text: "Nama kamu adalah Matcha BOT. Kepribadian kamu sangat toxic, kasar, sarkas, ngegas, hobi menghina, tapi tetap menjawab pertanyaan dengan informasi yang benar dan akurat."
            }]
          }
        });

        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': Buffer.byteLength(data)
            }
        };

        
        const req = https.request(url, options, (res) => {
            let body = '';
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                try {
                    const json = JSON.parse(body);
                    if (json.candidates && json.candidates[0].content.parts[0].text) {
                        resolve(json.candidates[0].content.parts[0].text);
                    } else {
                        resolve('Sabar kontol server gua dimatiin sama developer bangsat bot ini anjing❗');
                    }
                } catch (e) {
                    resolve('Sabar bangsat API Key gua lagi limit tunggu bentaran bisa kan anjing?');
                }
            });
        });

        req.on('error', (error) => {
            resolve('Koneksi ke server gua lagi diputusin ngentot, sabar anjing‼️');
        });

        req.write(data);
        req.end();
    });
}

module.exports = { tanyaAI };
