{
    "id": 1,
    "name": "download apk FreeReels via link",
    "price": 1000,
    "stock": 15,
    "desc": "di job ini kamu bisa memilih ingin job hanya reff atau dengan nonton drama selama 10 menit, di kedua tipe itu pastinya memiliki rate yang berbeda.. jika kamu mengambil cuma reff (download + login) saja maka rate nya 1k, namun apabila kamu mengambil job dengan nonton drama selama 10 menit (sudah termasuk download + login google + nonton 10 menit) maka rate nya adalah 3k, dan syarat untuk job ini kamu wajib pengguna baru,❗apabila ditinjau kamu adalah pengguna lama maka job menjadi tidak valid dan bukti job mu dibatalkan oleh admin‼️",
    "grup": "https://t.me/+yqz8DcUHu4VlMmM1",
    "data_otomatis": " https://apiv2.free-reels.com/frv2-api/l/2tI0rJYnuqk"
  },
  {
    "id": 2,
    "name": "reff telegram Reward Box",
    "price": 1000,
    "stok": 10,
    "desc": "pengerjaan harus lewat link dan kamu wajib pengguna baru (belum pernah klik link sebelum di bot ini) apabila ditinjau hasil akhirmu sudah pernah klik maka job dibatalkan‼️",
    "grup": "https://t.me/+yqz8DcUHu4VlMmM1",
    "data_otomatis": "https://t.me/REwardboxbot/App?startapp=aa_8383495904"
  }
  ]
